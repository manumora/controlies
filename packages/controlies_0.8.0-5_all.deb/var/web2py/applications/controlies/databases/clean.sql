delete from sesiones where timelogin<=  date('now','-12 months');
delete from maquinas where ultimorefresco<= date('now','-3 months');
delete from thinclients where time<= date('now','-3 months');
--Comentado, de momento no se borra: delete from logprinter where time<= date('now','-12 months');
vacuum;

