# coding: latin1

from applications.controlies.modules.Thinclients import Thinclients


def laptops():
    if not auth.user:
        session.flash='Debe iniciar sesi�n'
        redirect(URL(c='default',f='index'))
    return dict()

def printers():
    if not auth.user:
        session.flash='Debe iniciar sesi�n'
        redirect(URL(c='default',f='index'))
    return dict()

def users():
    if not auth.user:
        session.flash='Debe iniciar sesi�n'
        redirect(URL(c='default',f='index'))
    return dict()

@service.json 
def getClassrooms():
    import applications.controlies.modules.Utils.LdapUtils as LdapUtils
    l=conecta()
    response = LdapUtils.getAllGroups(l)
    l.close()
    return response

@auth.requires_login()      
def report():
        
    rows = getDataStudents(request.vars['classroom'])
    
    if len(rows)==0:
        return "noPeople"

    from gluon.contrib.pyfpdf import FPDF, HTMLMixin
        
    if request.vars["report_type"]=="compromisos":
        
        class MyFPDF(FPDF, HTMLMixin):
            def header(self):
                #logo=os.path.join(request.env.web2py_path,"applications","controlies","static","logo_consejeria.jpg")
                #self.image(logo,145,4,60)
                #self.ln(80)
                pass          
                
            def footer(self):
                #self.set_y(-15)
                #self.set_font('Arial','I',8)
                #self.cell(0,10,"IES Sta Eulalia - M�rida".decode("utf8").encode("latin1"),0,0,'L')
                #self.cell(0,10,"Consejer�a de Educaci�n - Gobierno de Extremadura".decode("utf8").encode("latin1"),0,0,'R')
                pass
            
        pdf=MyFPDF()
    
        count = 0
        titulo = "Compromiso para el cuidado y mantenimiento del ordenador port�til"
        
        for r in rows:
                
            parrafo1 = "Yo <b>"+r["cn"]+"</b> alumno/a de este centro perteneciente al curso/grupo <b>"+request.vars['classroom']+"</b>, me comprometo a cuidar, custodiar y mantener en perfecto estado el ORDENADOR <b>"+r['hostname']+"</b> (n�mero de serie: <b>"+r['serial_number']+"</b>) y ACCESORIOS que me ha entregado el centro para su uso en las distintas �reas de conocimientos, con la supervisi�n de los profesores/as correspondientes y siguiendo siempre las indicaciones e instrucciones para su correcto manejo."
            parrafo2 = "El deteriodo intencionado, p�rdida, robo o cualquier otra circunstancia que se produzca en el equipo ser� valorado por al Direcci�n/Jefatura del centro para tomar las medidas oportunas para su esclarecimiento y en su caso la reposici�n o arreglo por cuenta del alumno/a asignado/a, padres o tutores del mismo."        
            parrafo3 = "En ................ , a ...... de ....................... de ......"
            parrafo4 = "Firma del alumno: ....................................                     Firma de los padres/tutores: ...................................."
        
            if count%2==0:
                pdf.add_page()
            else:
                pdf.write_html("<br><br><br><center><p>______________________________________________________________________________________</p></center><br><br>")
    
            pdf.write_html("<center><h1>"+titulo+"</h1></center><br>")
            pdf.write_html("<p>"+parrafo1+"</p><br>")
            pdf.write_html("<p>"+parrafo2+"</p>")
            pdf.write_html("<br><br><center><p>"+parrafo3+"</p></center>")
            pdf.write_html("<br><br><br><br><center><p>"+parrafo4+"</p></center>")
            
            count+=1            
    
    elif request.vars["report_type"]=="listado":

        title = "Listado de dispositivos"

        html = """<table with='100%'>
                    <thead>
                    <tr><th>sdffsd</th><th></th><th></th></tr>
                    </thead>
                    <tbody>
                    <tr><td>sdffsd</td><td></td><td></td></tr>
                    <tr><td>sdffsd</td><td></td><td></td></tr>
                    </tbody>
                    </table>"""

        head = THEAD(TR(TH("N�",_width="5%"),
                        TH("Nombre y apellidos",_width="30%"),
                        TH("Equipo",_width="22%"),
                        TH("N� Serie",_width="30%"),
                        TH("Estado",_width="13%"),
                        _bgcolor="#A0A0A0"))

        rowsTable = []
        i=0;
        for r in rows:
            col = i % 2 and "#F0F0F0" or "#FFFFFF"
            rowsTable.append(TR(TD(i+1),
                           TD(r["cn"]),
                           TD(r["hostname"], _align="center"),
                           TD(r["serial_number"], _align="center"),
                           TD("", _align="center"),
                           _bgcolor=col))
            i+=1 

        body = TBODY(*rowsTable)
        table = TABLE(*[head, body], _border="1", _align="center", _width="100%")

        class MyFPDF(FPDF, HTMLMixin):
            def header(self):
                self.set_font('Arial','B',15)
                self.cell(0,10, title ,1,0,'C')
                self.set_font('Arial','I',10)
                
                self.text(20,29, "Grupo: "+request.vars['classroom'])
                    
                self.ln(10)
                
            def footer(self):
                self.set_y(-15)
                self.set_font('Arial','I',8)
                self.cell(0,10,"IES Sta Eulalia",0,0,'L')
                txt = 'P�gina %s de %s' % (self.page_no(), self.alias_nb_pages())
                self.cell(0,10,txt,0,0,'R')
                    
        pdf=MyFPDF()
        pdf.add_page()
        pdf.write_html('<font size="9">' +table.xml() + '</font>')
        
        
        
        

    response.headers['Content-Type']='application/pdf'
    doc=pdf.output(dest='S')
    doc64=embed64(data=doc,extension='application/pdf')    
    #return 'document.location="%s";' % doc64     
    return 'window.open("%s");' % doc64

def getDataStudents(classroom):
    from applications.controlies.modules.Groups import Groups

    l=conecta()
    g = Groups(l,"",classroom,"")
    listUsers = g.listUsers({'rows':'40', 'page':'1', 'sidx':'cn', 'sord':'desc'})
    
    h=Thinclients(l)
    listPrestamos= h.getUserAssignedHosts()
        
    l.close()
    
    rows=[]
    for r in listUsers["rows"]:
        
        if r["id"] in listPrestamos:
            host=listPrestamos[r["id"]]["host"]
            serial=listPrestamos[r["id"]]["serial"]
           
            if serial=="":
                serial = "                                              "
            
            r["cell"].append(host)
            r["cell"].append(serial)
            r["hostname"]=host
            r["serial_number"]=serial
            
            rows.append(r)
        
    return rows



@auth.requires_login()      
def report_printers():
    from gluon.contrib.pyfpdf import FPDF, HTMLMixin
                
    title = "Informe de impresiones"
    
    head = THEAD(TR(TH("Fecha/Hora",_width="22%"), 
                    TH("Impresora",_width="22%"),
                    TH("Host",_width="19%"),
                    TH("Usuario",_width="19%"),
                    TH("P�g",_width="5%"), 
                    TH("Cop",_width="5%"), 
                    TH("Total",_width="8%"),  
                    _bgcolor="#A0A0A0"))

    totalsum = cdb.logprinter.total.sum().with_alias('totalsum')

    rows=cdb(cdb.logprinter).select(cdb.logprinter.time,
                                    cdb.logprinter.impresora,
                                    cdb.logprinter.host,
                                    cdb.logprinter.usuario,
                                    cdb.logprinter.paginas,
                                    cdb.logprinter.copias,
                                    totalsum,
                                    groupby=cdb.logprinter.usuario,
                                    orderby=~cdb.logprinter.total.sum())
    
    rowsTable = []
    i=0;
    
    fields = " TD(r['logprinter']['time'], _align='center'),"
    fields+= " TD(r['logprinter']['impresora'], _align='center'),"
    fields+= " TD(r['logprinter']['host'], _align='center'),"
    fields+= " TD(r['logprinter']['usuario'], _align='center'),"
    fields+= " TD(r['logprinter']['paginas'], _align='center'),"
    fields+= " TD(r['logprinter']['copias'], _align='center'),"
    fields+= " TD(r['totalsum'], _align='center')"
    
    for r in rows:
        print r
        col = i % 2 and "#F0F0F0" or "#FFFFFF"
        """rowsTable.append(TR(TD(r['logprinter']['time'], _align="center"),
                       TD(r['logprinter']['impresora'], _align="center"),
                       TD(r['logprinter']['host'], _align="center"),
                       TD(r['logprinter']['usuario'], _align="center"),
                       TD(r['logprinter']['paginas'], _align="center"),
                       TD(r['logprinter']['copias'], _align="center"),
                       TD(r['totalsum'], _align="center"),
                       _bgcolor=col))"""
        rowsTable.append(TR(eval(fields), _bgcolor=col))
        i+=1 

    body = TBODY(*rowsTable)
    table = TABLE(*[head, body], _border="1", _align="center", _width="100%")

    class MyFPDF(FPDF, HTMLMixin):
        def header(self):
            self.set_font('Arial','B',15)
            self.cell(0,10, title ,1,0,'C')
            
        def footer(self):
            self.set_y(-15)
            self.set_font('Arial','I',8)
            self.cell(0,10,"IES Sta Eulalia",0,0,'L')
            txt = 'P�gina %s de %s' % (self.page_no(), self.alias_nb_pages())
            self.cell(0,10,txt,0,0,'R')
                
    pdf=MyFPDF()
    pdf.add_page()
    pdf.write_html(str(XML(table, sanitize=False)))        

    response.headers['Content-Type']='application/pdf'
    doc=pdf.output(dest='S')
    doc64=embed64(data=doc,extension='application/pdf')    
    return 'document.location="%s";' % doc64 


def call():
    """
    exposes services. for example:
    http://..../[app]/default/call/jsonrpc
    decorate with @services.jsonrpc the functions to expose
    supports xml, json, xmlrpc, jsonrpc, amfrpc, rss, csv
    """
    session.forget()
    return service()
