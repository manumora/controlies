##############################################################################
# -*- coding: utf-8 -*-
# Project:     ControlIES
# Module:    Netgroups.py
# Purpose:     NetGroups class
# Language:    Python 2.7
# Date:        15-Mar-2023
# Ver:         15-Mar-2023
# Author:   Alfonso Pastor Sierra 
# Copyright:    2023 - Alfonso Pastor Sierra <alfonso.pastor @no-spam@ gmail.com>
#
# ControlIES is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# ControlIES is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
# You should have received a copy of the GNU General Public License
# along with ControlIES. If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import ldap
import logging
from math import floor
from operator import itemgetter
from Utils import Utils, LdapUtils
import types

class NetGroups(object):

    def __init__(self):
        pass
    
    def __init__(self,ldap,name,members):
        self.ldap = ldap
        self.name = Utils.parseToLdap(name)
        self.original_name=""
        self.members = members

    def exists_netgroup_name(self):
        
        result = self.ldap.search("ou=Netgroup","cn="+self.name,["cn"])
        if len(result) > 0:
            return True
        
        return False
                
    def validation(self,action):

        if self.name == "":
            return "name"    
        
        if action == "add" and self.exists_netgroup_name(): 
             return "name_dup"

        if action == "modify":
            if self.name == self.original_name: return "name_change"
            if  self.exists_netgroup_name(): return "name_dup"
            
        return "OK"

    def process(self,action,name_netgroup):
    
        self.original_name=name_netgroup # Nombre original del netgroup
        response = self.validation(action)
        if response == "OK":
            if action == "add":
                response = self.add()
            elif action == "modify":
                response = self.modify()
        return response     
            
    def list(self,args):
        
        if str(args['cn'])!="None":
            filter = "(cn=*" + str(args['cn']) + "*)"
        else:
            filter = "(cn=*)"

        search = self.ldap.search("ou=Netgroup",filter,["cn","nisNetgroupTriple"])

        # grid parameters
        limit = int(args['rows'])
        page = int(args['page'])
        start = limit * page - limit
        finish = start + limit;             

        # sort by field
        sortBy = args['sidx']
        if sortBy == "cn":
            sortBy = "id"

        # reverse Sort
        reverseSort = False
        if args['sord']== "asc":
            reverseSort = True


        rows = []
        for i in search:
            
                listaHosts = ""
                try:
                    list2 = [x for x in i[0][1]["nisNetgroupTriple"] if x]
                    hostsNumber = len(list2)
                    listaHosts=" ".join(list2).replace("(","").replace(",-,-)","")
                except:
                    hostsNumber = 0

                host_search = str(args['hosts'])

                if host_search != "None" and host_search != "" and listaHosts.find(host_search) == -1 :  continue

                row = {
                    "id":i[0][1]["cn"][0], 
                    "cell":[i[0][1]["cn"][0], hostsNumber, listaHosts],                 
                    "cn": i[0][1]["cn"][0],
                    "hostsNumber": hostsNumber,
                    "hosts": listaHosts
                }
                rows.append(row)                
                                
            
        if len(rows) > 0:
            totalPages = floor( len(rows) / int(limit) )
            module = len(rows) % int(limit)

            if module > 0:
                totalPages = totalPages+1
        else:
            totalPages = 0

        if page > totalPages:
            page = totalPages

        # sort rows
        result = sorted(rows, key=itemgetter(sortBy), reverse=reverseSort)

        return { "page":page, "total":totalPages, "records":len(rows), "rows":result[start:finish] }
        

    def add(self):
        
        attr = [
        ('objectclass', ['top','nisNetgroup']),
        ('cn', [self.name] )
        ]

        self.ldap.add("cn="+self.name+",ou=Netgroup", attr)

        return "OK"

            
    def modify(self):

        #Solo se cambia el nombre, no lo miembros del grupo

        self.ldap.rename("ou=NetGroup", "cn="+self.original_name, "cn="+self.name)

        return "OK"

    def delete(self):
        self.ldap.delete('cn='+ self.name +',ou=Netgroup')

        return "OK"
        

    def getNetGroupData(self):

        result = self.ldap.search("ou=Netgroup","cn="+self.name,["cn","nisNetgroupTriple"])

        try:
             m = result[0][0][1]["nisNetgroupTriple"]
             members = [x for x in m if x]
             members.sort()
        except:
             members=[]

        dataGroup = {
            "name":result[0][0][1]["cn"][0],
            "nisNetgroupTriple":members
         }
         
        return dataGroup
        


def log(mensaje):
    logfile = open("/tmp/controlies.txt", "a")
    logfile.write(mensaje+"\n")
    logfile.close()


